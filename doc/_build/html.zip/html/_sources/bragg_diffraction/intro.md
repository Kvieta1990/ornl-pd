Bragg Diffraction
===